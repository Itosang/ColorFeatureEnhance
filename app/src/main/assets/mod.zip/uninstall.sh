#!/system/bin/sh
# uninstall.sh 在模块被卸载（且需重启生效）时执行，用于清理模块产生的额外文件/数据。
# 注意：$MODPATH 下的文件由 Magisk 自动删除，无需在这里删除。

# 在此添加你的清理逻辑

exit 0
